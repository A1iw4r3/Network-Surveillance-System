using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Network_Surveillance_System
{
    public partial class FarmMain : Form
    {

        Devices[] devLst = new Devices[8];

        int devIndex = 0;

        Devices selectedDev;

        private bool LoggedIn;


        public FarmMain()
        {
            InitializeComponent();

            HomePnl.Visible = true;
            LoginPnl.Visible = false;
            SimulatePnl.Visible = false;
            StatisticPnl.Visible = false;

            devLst[0] = new Devices("Desktop 1");
            devLst[1] = new Devices("Desktop 2");
            devLst[2] = new Devices("Server");
            devLst[3] = new Devices("Switch");
            devLst[4] = new Devices("Router");
            devLst[5] = new Devices("Firewall");
            devLst[6] = new Devices("Laptop");
            devLst[7] = new Devices("Smart Phone");

            selectedDev = new Devices();
            LoggedIn = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HomePnl.Visible = true;
            LoginPnl.Visible = false;
            SimulatePnl.Visible = false;
            StatisticPnl.Visible = false;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            HomePnl.Visible = false;
            LoginPnl.Visible = true;
            SimulatePnl.Visible = false;
            StatisticPnl.Visible = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (LoggedIn)
            {
                HomePnl.Visible = false;
                LoginPnl.Visible = false;
                SimulatePnl.Visible = true;
                StatisticPnl.Visible = false;
            }
            else
            {
                MessageBox.Show("You are not logged In!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (LoggedIn)
            {
                HomePnl.Visible = false;
                LoginPnl.Visible = false;
                SimulatePnl.Visible = false;
                StatisticPnl.Visible = true;
            }
            else
            {
                MessageBox.Show("You are not logged In!");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (LoggedIn)
            {
                HomePnl.Visible = false;
                LoginPnl.Visible = false;
                SimulatePnl.Visible = true;
                StatisticPnl.Visible = false;
            }
            else
            {
                MessageBox.Show("You are not logged In!");
            }

        }


        private void button6_Click(object sender, EventArgs e)
        {
            if (TxtUserName.Text == "Admin" && TxtPassword.Text == "123")
            {
                LoggedIn = true;
                MessageBox.Show("Loggin In Succesfully");
                HomePnl.Visible = true;
                LoginPnl.Visible = false;
                SimulatePnl.Visible = false;
                StatisticPnl.Visible = false;
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password");
            }
            TxtUserName.Clear();
            TxtPassword.Clear();
        }

        private void FormClosePic_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormMaximizePic_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }


        }

        private void FormMinimizePic_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            devLst[devIndex].conn();
            PictureBox pb = getPictureBox("pictureBox" + (devIndex + 15));



            if (selectedDev.isConn())
            {
                pb.Visible = true;
            }
            else
            {
                pb.Visible = false;
            }
        }

        private PictureBox getPictureBox(string s)
        {
            return (PictureBox)FarmMain.ActiveForm.Controls.Find(s, true)[0];
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

            string a = contextMenuStrip1.SourceControl.Name.ToString();
            devIndex = Int32.Parse(Regex.Match(a, @"\d+").Value) - 5;
            selectedDev = devLst[devIndex];

            viewDataToolStripMenuItem.Text = "View Info for " + devLst[devIndex].getName();
            if (selectedDev.getName() == "Firewall" || selectedDev.getName() == "Switch")
            {
                sendMessageToolStripMenuItem.Enabled = false;
            }
            else
            {
                sendMessageToolStripMenuItem.Enabled = true;
            }
        }

        private void pingDevice_Click(object sender, EventArgs e)
        {
            string name = ((ToolStripMenuItem)sender).Text;
            Devices tempDev = new Devices();

            foreach (Devices dev in devLst)
            {
                if (dev.getName() == name)
                {
                    tempDev = dev;
                    break;
                }
            }
            if (selectedDev.isConn())
            {
                random obj = new random();
                int seconds = obj.random_no();
                if (tempDev.isConn())
                {
                    if (seconds >= 5)
                    {
                        print("Ping Unsuccessful");
                        print("The Device you're trying to Ping is Unreachable.");
                    }
                    else
                    {
                        print("Ping from \"" + selectedDev.getName() + "\" to \"" + name + "\" Successfull");
                    }

                }
                else
                {
                    print("Ping Failed! Destination Device \"" + name + "\" Not Connected.");
                }
            }
            else
            {
                print("Ping Failed! Source Device \"" + selectedDev.getName() + "\" Not Connected.");
            }

        }
        public void print(string s)
        {
            statsOut.Text += s + "\n";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            HomePnl.Visible = false;
            LoginPnl.Visible = true;
            SimulatePnl.Visible = false;
            StatisticPnl.Visible = false;
        }

        private void viewDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string a = contextMenuStrip1.SourceControl.Name.ToString();
            devIndex = Int32.Parse(Regex.Match(a, @"\d+").Value) - 5;

            if (devLst[devIndex].isConn())
            {

                if (devLst[devIndex].getName() == "Desktop 1")
                {
                    print("--");
                    print("Device Name: " + devLst[devIndex].getName());
                    print("Device Type : Desktop PC 1");
                    print("OS : Windows 10");
                    print("IP Address: 192.168.1.3");
                    print("MAC Address : B2-FB-5A-DA-02-01");
                    print("--");
                }
                else if (devLst[devIndex].getName() == "Desktop 2")
                {
                    print("--");
                    print("Device Name : " + devLst[devIndex].getName());
                    print("Device Type : Desktop PC 2");
                    print("OS : Windows 11");
                    print("IP Address : 192.168.1.4");
                    print("MAC Address : X5-2A-5E-A9-76-8C");
                    print("--");
                }
                else if (devLst[devIndex].getName() == "Server")
                {
                    print("--");
                    print("Device Name: " + devLst[devIndex].getName());
                    print("Device Type : DNS Server");
                    print("OS : KALI LINUX");
                    print("IP Address: 192.168.1.2");
                    print("MAC Address : XC-61-5B-2F-A3-3A");
                    print("--");

                }
                else if (devLst[devIndex].getName() == "Switch")
                {
                    print("--");
                    print("Device Name: " + devLst[devIndex].getName());
                    print("Device Type : Cisco Switch");
                    print("Model Number : Cisco Catalyst 2960");
                    print("--");

                }
                else if (devLst[devIndex].getName() == "Router")
                {
                    print("--");
                    print("Device Name: " + devLst[devIndex].getName());
                    print("Device Manufacturer : Cisco");
                    print("Model Number : Cisco ISR 4000 Series");
                    print("MAC Address : 1A:2B:3C:4D:5E:6F");
                    print("IP Address : 192.168.1.1");
                    print("        >---------------<Network Details---------------<");
                    print("Device Name                IP_Address           Mac_Address");
                    print("Server                     192.168.1.2          XC-61-5B-2F-A3-3A");
                    print("Cisco Router               192.168.1.1          1A:2B:3C:4D:5E:6F");
                    print("Desktop 1                  192.168.1.3          B2-FB-5A-DA-02-01");
                    print("Desktop 2                  192.168.1.4          X5-2A-5E-A9-76-8C");
                    print("Laptop                     192.168.1.5          52:74:9d:ab:5f:21");
                    print("Smart phone                192.168.1.6          6A:8B:1C:9D:2E:3F");
                    print("        >----------------------------------------------<");
                    print("--");
                }

                else if (devLst[devIndex].getName() == "Firewall")
                {
                    print("--");
                    print("Device Name: " + devLst[devIndex].getName());
                    print("Device Manufacturer : Fortinet");
                    print("Model Number : Fortinet FortiGate 6000 Series");
                    print("VPN Support : IPsec VPN");
                    print("--");
                }

                else if (devLst[devIndex].getName() == "Laptop")
                {
                    print("--");
                    print("Device Name: " + devLst[devIndex].getName());
                    print("Device Type : Dell Laptop");
                    print("OS : Windows 11");
                    print("IP Address: 192.168.1.5");
                    print("MAC Address : 52:74:9d:ab:5f:21");
                    print("--");
                }
                else if (devLst[devIndex].getName() == "Smart Phone")
                {
                    print("--");
                    print("Device Name: " + devLst[devIndex].getName());
                    print("Device Type : Smartphone");
                    print("OS : Android");
                    print("IP Address: 192.168.1.6");
                    print("MAC Address : 6A:8B:1C:9D:2E:3F");
                    print("--");
                }
            }
            else
            {
                print("Device \"" + devLst[devIndex].getName() + "\" not connected to the Network!");
            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LeftPnl_Paint(object sender, PaintEventArgs e)
        {
        }

        private void StatisticPnl_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TrapButton_Click(object sender, EventArgs e)
        {
            // Clear the existing content in the rich text box
            statsOut.Clear();

            // Iterate through each device and display its data
            foreach (Devices device in devLst)
            {
                statsOut.AppendText("Device Name: " + device.getName() + "\n");
                statsOut.AppendText("Connected: " + (device.isConn() ? "Yes" : "No") + "\n");

                // Add more properties or information about the device here
                // Example: statsOut.AppendText("IP Address: " + device.GetIPAddress() + "\n");

                statsOut.AppendText("-------------------------\n");
            }
        }


    }

    class Devices
    {
        private bool connected;

        private string name;

        public Devices()
        {
            connected = false;
            name = "";
        }

        public Devices(string n)
        {
            connected = false;
            name = n;
        }
        public string getName()
        {
            return name;

        }

        public void setName(string n)
        {
            name = n;
        }

        public void conn()
        {
            connected = !connected;
        }

        public bool isConn()
        {
            return connected;
        }
    }
    class random
    {
        public int random_no()
        {
            Random random = new Random();
            int randomNumber = random.Next(6); // generates a random number between 0 and 8
            return randomNumber;
        }
    }
}