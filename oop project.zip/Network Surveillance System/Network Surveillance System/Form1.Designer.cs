﻿namespace Network_Surveillance_System
{
    partial class FarmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FarmMain));
            LeftPnl = new Panel();
            pictureBox9 = new PictureBox();
            panel3 = new Panel();
            button3 = new Button();
            panel2 = new Panel();
            ButtonLogin = new Button();
            panel1 = new Panel();
            ButtonSimulate = new Button();
            PnlOnButtonHome = new Panel();
            ButtonHome = new Button();
            StatisticPnl = new Panel();
            statsOut = new RichTextBox();
            panel18 = new Panel();
            UpperPnl = new Panel();
            label4 = new Label();
            FormMaximizePic = new PictureBox();
            FormMinimizePic = new PictureBox();
            FormClosePic = new PictureBox();
            HomePnl = new Panel();
            panel4 = new Panel();
            button5 = new Button();
            button4 = new Button();
            textBox1 = new TextBox();
            pictureBox4 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            LoginPnl = new Panel();
            LoginFarmPnl = new Panel();
            TxtPassword = new TextBox();
            TxtUserName = new TextBox();
            pictureBox6 = new PictureBox();
            button6 = new Button();
            panel7 = new Panel();
            panel5 = new Panel();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            label3 = new Label();
            panel6 = new Panel();
            pictureBox5 = new PictureBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            connectToolStripMenuItem = new ToolStripMenuItem();
            viewDataToolStripMenuItem = new ToolStripMenuItem();
            sendMessageToolStripMenuItem = new ToolStripMenuItem();
            desktop1ToolStripMenuItem = new ToolStripMenuItem();
            desktop2ToolStripMenuItem = new ToolStripMenuItem();
            serverToolStripMenuItem = new ToolStripMenuItem();
            routerToolStripMenuItem = new ToolStripMenuItem();
            laptopToolStripMenuItem = new ToolStripMenuItem();
            smartPhoneToolStripMenuItem = new ToolStripMenuItem();
            SimulatePnl = new Panel();
            label13 = new Label();
            panel12 = new Panel();
            pictureBox18 = new PictureBox();
            label8 = new Label();
            pictureBox10 = new PictureBox();
            panel11 = new Panel();
            pictureBox17 = new PictureBox();
            label7 = new Label();
            pictureBox3 = new PictureBox();
            panel10 = new Panel();
            pictureBox16 = new PictureBox();
            label14 = new Label();
            label6 = new Label();
            pictureBox2 = new PictureBox();
            panel16 = new Panel();
            pictureBox22 = new PictureBox();
            label12 = new Label();
            pictureBox14 = new PictureBox();
            panel15 = new Panel();
            pictureBox21 = new PictureBox();
            label11 = new Label();
            pictureBox13 = new PictureBox();
            panel14 = new Panel();
            pictureBox20 = new PictureBox();
            label10 = new Label();
            pictureBox12 = new PictureBox();
            panel13 = new Panel();
            pictureBox19 = new PictureBox();
            label9 = new Label();
            pictureBox11 = new PictureBox();
            panel8 = new Panel();
            pictureBox15 = new PictureBox();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            panel9 = new Panel();
            TrapButton = new Button();
            LeftPnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            StatisticPnl.SuspendLayout();
            UpperPnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)FormMaximizePic).BeginInit();
            ((System.ComponentModel.ISupportInitialize)FormMinimizePic).BeginInit();
            ((System.ComponentModel.ISupportInitialize)FormClosePic).BeginInit();
            HomePnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            LoginPnl.SuspendLayout();
            LoginFarmPnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            contextMenuStrip1.SuspendLayout();
            SimulatePnl.SuspendLayout();
            panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // LeftPnl
            // 
            LeftPnl.BackColor = Color.LimeGreen;
            LeftPnl.Controls.Add(pictureBox9);
            LeftPnl.Controls.Add(panel3);
            LeftPnl.Controls.Add(button3);
            LeftPnl.Controls.Add(panel2);
            LeftPnl.Controls.Add(ButtonLogin);
            LeftPnl.Controls.Add(panel1);
            LeftPnl.Controls.Add(ButtonSimulate);
            LeftPnl.Controls.Add(PnlOnButtonHome);
            LeftPnl.Controls.Add(ButtonHome);
            LeftPnl.Dock = DockStyle.Left;
            LeftPnl.Location = new Point(0, 0);
            LeftPnl.Name = "LeftPnl";
            LeftPnl.Size = new Size(210, 517);
            LeftPnl.TabIndex = 0;
            LeftPnl.Paint += LeftPnl_Paint;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.globalization;
            pictureBox9.Location = new Point(17, 6);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(176, 100);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 7;
            pictureBox9.TabStop = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Orange;
            panel3.Location = new Point(-1, 376);
            panel3.Name = "panel3";
            panel3.Size = new Size(16, 40);
            panel3.TabIndex = 5;
            // 
            // button3
            // 
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor = Color.White;
            button3.Image = Properties.Resources.Display;
            button3.Location = new Point(17, 359);
            button3.Name = "button3";
            button3.Size = new Size(189, 73);
            button3.TabIndex = 6;
            button3.Text = " Statistic";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Orange;
            panel2.Location = new Point(0, 208);
            panel2.Name = "panel2";
            panel2.Size = new Size(16, 40);
            panel2.TabIndex = 3;
            panel2.Paint += panel2_Paint;
            // 
            // ButtonLogin
            // 
            ButtonLogin.FlatAppearance.BorderSize = 0;
            ButtonLogin.FlatStyle = FlatStyle.Flat;
            ButtonLogin.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            ButtonLogin.ForeColor = Color.White;
            ButtonLogin.Image = Properties.Resources.Login_Ill;
            ButtonLogin.Location = new Point(14, 191);
            ButtonLogin.Name = "ButtonLogin";
            ButtonLogin.Size = new Size(189, 73);
            ButtonLogin.TabIndex = 4;
            ButtonLogin.Text = "  Login";
            ButtonLogin.TextImageRelation = TextImageRelation.ImageBeforeText;
            ButtonLogin.UseVisualStyleBackColor = true;
            ButtonLogin.Click += button2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Orange;
            panel1.Location = new Point(0, 290);
            panel1.Name = "panel1";
            panel1.Size = new Size(16, 40);
            panel1.TabIndex = 1;
            // 
            // ButtonSimulate
            // 
            ButtonSimulate.FlatAppearance.BorderSize = 0;
            ButtonSimulate.FlatStyle = FlatStyle.Flat;
            ButtonSimulate.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            ButtonSimulate.ForeColor = Color.White;
            ButtonSimulate.Image = Properties.Resources.Simulation;
            ButtonSimulate.Location = new Point(21, 273);
            ButtonSimulate.Name = "ButtonSimulate";
            ButtonSimulate.Size = new Size(189, 73);
            ButtonSimulate.TabIndex = 2;
            ButtonSimulate.Text = "  Simulate";
            ButtonSimulate.TextImageRelation = TextImageRelation.ImageBeforeText;
            ButtonSimulate.UseVisualStyleBackColor = true;
            ButtonSimulate.Click += button1_Click_1;
            // 
            // PnlOnButtonHome
            // 
            PnlOnButtonHome.BackColor = Color.Orange;
            PnlOnButtonHome.Location = new Point(0, 126);
            PnlOnButtonHome.Name = "PnlOnButtonHome";
            PnlOnButtonHome.Size = new Size(16, 40);
            PnlOnButtonHome.TabIndex = 0;
            // 
            // ButtonHome
            // 
            ButtonHome.FlatAppearance.BorderSize = 0;
            ButtonHome.FlatStyle = FlatStyle.Flat;
            ButtonHome.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            ButtonHome.ForeColor = Color.White;
            ButtonHome.Image = Properties.Resources.Home_PNG;
            ButtonHome.Location = new Point(16, 110);
            ButtonHome.Name = "ButtonHome";
            ButtonHome.Size = new Size(189, 73);
            ButtonHome.TabIndex = 0;
            ButtonHome.Text = "  Home";
            ButtonHome.TextImageRelation = TextImageRelation.ImageBeforeText;
            ButtonHome.UseVisualStyleBackColor = true;
            ButtonHome.Click += button1_Click;
            // 
            // StatisticPnl
            // 
            StatisticPnl.BackColor = Color.White;
            StatisticPnl.Controls.Add(statsOut);
            StatisticPnl.Controls.Add(panel18);
            StatisticPnl.Location = new Point(209, 39);
            StatisticPnl.Name = "StatisticPnl";
            StatisticPnl.Size = new Size(891, 478);
            StatisticPnl.TabIndex = 8;
            StatisticPnl.Paint += StatisticPnl_Paint;
            // 
            // statsOut
            // 
            statsOut.BackColor = Color.Black;
            statsOut.BorderStyle = BorderStyle.None;
            statsOut.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            statsOut.ForeColor = Color.LawnGreen;
            statsOut.Location = new Point(0, 0);
            statsOut.Margin = new Padding(4, 5, 4, 5);
            statsOut.Name = "statsOut";
            statsOut.ReadOnly = true;
            statsOut.Size = new Size(891, 445);
            statsOut.TabIndex = 7;
            statsOut.Text = "";
            // 
            // panel18
            // 
            panel18.BackColor = Color.YellowGreen;
            panel18.Dock = DockStyle.Bottom;
            panel18.Location = new Point(0, 440);
            panel18.Name = "panel18";
            panel18.Size = new Size(891, 38);
            panel18.TabIndex = 6;
            // 
            // UpperPnl
            // 
            UpperPnl.BackColor = Color.YellowGreen;
            UpperPnl.Controls.Add(label4);
            UpperPnl.Controls.Add(FormMaximizePic);
            UpperPnl.Controls.Add(FormMinimizePic);
            UpperPnl.Controls.Add(FormClosePic);
            UpperPnl.Dock = DockStyle.Top;
            UpperPnl.Location = new Point(210, 0);
            UpperPnl.Name = "UpperPnl";
            UpperPnl.Size = new Size(891, 42);
            UpperPnl.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(246, 5);
            label4.Name = "label4";
            label4.Size = new Size(333, 29);
            label4.TabIndex = 3;
            label4.Text = "Network Monitoring System";
            // 
            // FormMaximizePic
            // 
            FormMaximizePic.Image = Properties.Resources.Maximize1;
            FormMaximizePic.Location = new Point(810, 7);
            FormMaximizePic.Name = "FormMaximizePic";
            FormMaximizePic.Size = new Size(30, 27);
            FormMaximizePic.SizeMode = PictureBoxSizeMode.Zoom;
            FormMaximizePic.TabIndex = 2;
            FormMaximizePic.TabStop = false;
            FormMaximizePic.Click += FormMaximizePic_Click;
            // 
            // FormMinimizePic
            // 
            FormMinimizePic.Image = Properties.Resources.Minimize1;
            FormMinimizePic.Location = new Point(774, 7);
            FormMinimizePic.Name = "FormMinimizePic";
            FormMinimizePic.Size = new Size(30, 27);
            FormMinimizePic.SizeMode = PictureBoxSizeMode.Zoom;
            FormMinimizePic.TabIndex = 1;
            FormMinimizePic.TabStop = false;
            FormMinimizePic.Click += FormMinimizePic_Click;
            // 
            // FormClosePic
            // 
            FormClosePic.Image = Properties.Resources.Cross1;
            FormClosePic.Location = new Point(846, 7);
            FormClosePic.Name = "FormClosePic";
            FormClosePic.Size = new Size(30, 27);
            FormClosePic.SizeMode = PictureBoxSizeMode.Zoom;
            FormClosePic.TabIndex = 0;
            FormClosePic.TabStop = false;
            FormClosePic.Click += FormClosePic_Click;
            // 
            // HomePnl
            // 
            HomePnl.BackColor = Color.White;
            HomePnl.Controls.Add(panel4);
            HomePnl.Controls.Add(button5);
            HomePnl.Controls.Add(button4);
            HomePnl.Controls.Add(textBox1);
            HomePnl.Controls.Add(pictureBox4);
            HomePnl.Controls.Add(label2);
            HomePnl.Controls.Add(label1);
            HomePnl.Location = new Point(210, 38);
            HomePnl.Name = "HomePnl";
            HomePnl.Size = new Size(891, 478);
            HomePnl.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.BackColor = Color.YellowGreen;
            panel4.Dock = DockStyle.Bottom;
            panel4.Location = new Point(0, 440);
            panel4.Name = "panel4";
            panel4.Size = new Size(891, 38);
            panel4.TabIndex = 6;
            // 
            // button5
            // 
            button5.BackColor = Color.LawnGreen;
            button5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(226, 328);
            button5.Name = "button5";
            button5.Size = new Size(154, 43);
            button5.TabIndex = 5;
            button5.Text = "Login";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.LawnGreen;
            button4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(33, 328);
            button4.Name = "button4";
            button4.Size = new Size(154, 43);
            button4.TabIndex = 4;
            button4.Text = "Get Started";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.ForeColor = Color.Black;
            textBox1.Location = new Point(33, 270);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(378, 31);
            textBox1.TabIndex = 3;
            textBox1.Text = "  Enter Your E-mail Address";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Crud_pic;
            pictureBox4.Location = new Point(486, 43);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(407, 348);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(64, 64, 64);
            label2.Location = new Point(33, 182);
            label2.Name = "label2";
            label2.Size = new Size(434, 58);
            label2.TabIndex = 1;
            label2.Text = "The Best Monitoring System to Monitor \r\nNetwork Devices and Resources.";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(33, 85);
            label1.Name = "label1";
            label1.Size = new Size(356, 80);
            label1.TabIndex = 0;
            label1.Text = "Network Monitoring \r\nSystem";
            // 
            // LoginPnl
            // 
            LoginPnl.BackColor = Color.White;
            LoginPnl.Controls.Add(LoginFarmPnl);
            LoginPnl.Controls.Add(panel6);
            LoginPnl.Controls.Add(pictureBox5);
            LoginPnl.Location = new Point(210, 38);
            LoginPnl.Name = "LoginPnl";
            LoginPnl.Size = new Size(891, 478);
            LoginPnl.TabIndex = 3;
            // 
            // LoginFarmPnl
            // 
            LoginFarmPnl.BackColor = Color.White;
            LoginFarmPnl.Controls.Add(TxtPassword);
            LoginFarmPnl.Controls.Add(TxtUserName);
            LoginFarmPnl.Controls.Add(pictureBox6);
            LoginFarmPnl.Controls.Add(button6);
            LoginFarmPnl.Controls.Add(panel7);
            LoginFarmPnl.Controls.Add(panel5);
            LoginFarmPnl.Controls.Add(pictureBox8);
            LoginFarmPnl.Controls.Add(pictureBox7);
            LoginFarmPnl.Controls.Add(label3);
            LoginFarmPnl.Location = new Point(520, 22);
            LoginFarmPnl.Name = "LoginFarmPnl";
            LoginFarmPnl.Size = new Size(307, 398);
            LoginFarmPnl.TabIndex = 7;
            // 
            // TxtPassword
            // 
            TxtPassword.BorderStyle = BorderStyle.None;
            TxtPassword.Font = new Font("Kingston", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtPassword.ForeColor = Color.LimeGreen;
            TxtPassword.Location = new Point(84, 270);
            TxtPassword.Name = "TxtPassword";
            TxtPassword.Size = new Size(200, 28);
            TxtPassword.TabIndex = 6;
            // 
            // TxtUserName
            // 
            TxtUserName.BackColor = Color.White;
            TxtUserName.BorderStyle = BorderStyle.None;
            TxtUserName.Font = new Font("Kingston", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtUserName.ForeColor = Color.LimeGreen;
            TxtUserName.Location = new Point(84, 200);
            TxtUserName.Name = "TxtUserName";
            TxtUserName.Size = new Size(200, 28);
            TxtUserName.TabIndex = 6;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Green_Wifi;
            pictureBox6.Location = new Point(103, 13);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(166, 102);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 5;
            pictureBox6.TabStop = false;
            // 
            // button6
            // 
            button6.BackColor = Color.LimeGreen;
            button6.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button6.ForeColor = Color.White;
            button6.Location = new Point(121, 332);
            button6.Name = "button6";
            button6.Size = new Size(129, 40);
            button6.TabIndex = 4;
            button6.Text = "Login";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.LimeGreen;
            panel7.Location = new Point(84, 303);
            panel7.Name = "panel7";
            panel7.Size = new Size(203, 2);
            panel7.TabIndex = 3;
            // 
            // panel5
            // 
            panel5.BackColor = Color.LimeGreen;
            panel5.Location = new Point(84, 233);
            panel5.Name = "panel5";
            panel5.Size = new Size(203, 2);
            panel5.TabIndex = 3;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.safe;
            pictureBox8.Location = new Point(21, 265);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(49, 45);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 2;
            pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Username;
            pictureBox7.Location = new Point(21, 195);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(49, 45);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.LimeGreen;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(114, 142);
            label3.Name = "label3";
            label3.Size = new Size(140, 29);
            label3.TabIndex = 1;
            label3.Text = "Login User";
            // 
            // panel6
            // 
            panel6.BackColor = Color.YellowGreen;
            panel6.Dock = DockStyle.Bottom;
            panel6.Location = new Point(0, 440);
            panel6.Name = "panel6";
            panel6.Size = new Size(891, 38);
            panel6.TabIndex = 6;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Man_Login_Comp;
            pictureBox5.Location = new Point(0, 0);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(527, 445);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 2;
            pictureBox5.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.BackColor = Color.Black;
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { connectToolStripMenuItem, viewDataToolStripMenuItem, sendMessageToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(251, 100);
            contextMenuStrip1.Opening += contextMenuStrip1_Opening;
            // 
            // connectToolStripMenuItem
            // 
            connectToolStripMenuItem.ForeColor = Color.White;
            connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            connectToolStripMenuItem.Size = new Size(250, 32);
            connectToolStripMenuItem.Text = "Connect to Network";
            connectToolStripMenuItem.Click += connectToolStripMenuItem_Click;
            // 
            // viewDataToolStripMenuItem
            // 
            viewDataToolStripMenuItem.ForeColor = Color.White;
            viewDataToolStripMenuItem.Name = "viewDataToolStripMenuItem";
            viewDataToolStripMenuItem.Size = new Size(250, 32);
            viewDataToolStripMenuItem.Text = "View Desktop 1 Data";
            viewDataToolStripMenuItem.Click += viewDataToolStripMenuItem_Click;
            // 
            // sendMessageToolStripMenuItem
            // 
            sendMessageToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { desktop1ToolStripMenuItem, desktop2ToolStripMenuItem, serverToolStripMenuItem, routerToolStripMenuItem, laptopToolStripMenuItem, smartPhoneToolStripMenuItem });
            sendMessageToolStripMenuItem.ForeColor = Color.White;
            sendMessageToolStripMenuItem.Name = "sendMessageToolStripMenuItem";
            sendMessageToolStripMenuItem.Size = new Size(250, 32);
            sendMessageToolStripMenuItem.Text = "Send Message";
            // 
            // desktop1ToolStripMenuItem
            // 
            desktop1ToolStripMenuItem.BackColor = Color.Black;
            desktop1ToolStripMenuItem.ForeColor = Color.White;
            desktop1ToolStripMenuItem.Name = "desktop1ToolStripMenuItem";
            desktop1ToolStripMenuItem.Size = new Size(216, 34);
            desktop1ToolStripMenuItem.Text = "Desktop 1";
            desktop1ToolStripMenuItem.Click += pingDevice_Click;
            // 
            // desktop2ToolStripMenuItem
            // 
            desktop2ToolStripMenuItem.BackColor = Color.Black;
            desktop2ToolStripMenuItem.ForeColor = Color.White;
            desktop2ToolStripMenuItem.Name = "desktop2ToolStripMenuItem";
            desktop2ToolStripMenuItem.Size = new Size(216, 34);
            desktop2ToolStripMenuItem.Text = "Desktop 2";
            desktop2ToolStripMenuItem.Click += pingDevice_Click;
            // 
            // serverToolStripMenuItem
            // 
            serverToolStripMenuItem.BackColor = Color.Black;
            serverToolStripMenuItem.ForeColor = Color.White;
            serverToolStripMenuItem.Name = "serverToolStripMenuItem";
            serverToolStripMenuItem.Size = new Size(216, 34);
            serverToolStripMenuItem.Text = "Server";
            serverToolStripMenuItem.Click += pingDevice_Click;
            // 
            // routerToolStripMenuItem
            // 
            routerToolStripMenuItem.BackColor = Color.Black;
            routerToolStripMenuItem.ForeColor = Color.White;
            routerToolStripMenuItem.Name = "routerToolStripMenuItem";
            routerToolStripMenuItem.Size = new Size(216, 34);
            routerToolStripMenuItem.Text = "Router";
            routerToolStripMenuItem.Click += pingDevice_Click;
            // 
            // laptopToolStripMenuItem
            // 
            laptopToolStripMenuItem.BackColor = Color.Black;
            laptopToolStripMenuItem.ForeColor = Color.White;
            laptopToolStripMenuItem.Name = "laptopToolStripMenuItem";
            laptopToolStripMenuItem.Size = new Size(216, 34);
            laptopToolStripMenuItem.Text = "Laptop";
            laptopToolStripMenuItem.Click += pingDevice_Click;
            // 
            // smartPhoneToolStripMenuItem
            // 
            smartPhoneToolStripMenuItem.BackColor = Color.Black;
            smartPhoneToolStripMenuItem.ForeColor = Color.White;
            smartPhoneToolStripMenuItem.Name = "smartPhoneToolStripMenuItem";
            smartPhoneToolStripMenuItem.Size = new Size(216, 34);
            smartPhoneToolStripMenuItem.Text = "Smart Phone";
            smartPhoneToolStripMenuItem.Click += pingDevice_Click;
            // 
            // SimulatePnl
            // 
            SimulatePnl.BackColor = Color.White;
            SimulatePnl.Controls.Add(TrapButton);
            SimulatePnl.Controls.Add(label13);
            SimulatePnl.Controls.Add(panel12);
            SimulatePnl.Controls.Add(panel11);
            SimulatePnl.Controls.Add(panel10);
            SimulatePnl.Controls.Add(panel16);
            SimulatePnl.Controls.Add(panel15);
            SimulatePnl.Controls.Add(panel14);
            SimulatePnl.Controls.Add(panel13);
            SimulatePnl.Controls.Add(panel8);
            SimulatePnl.Controls.Add(panel9);
            SimulatePnl.Location = new Point(210, 38);
            SimulatePnl.Name = "SimulatePnl";
            SimulatePnl.Size = new Size(891, 478);
            SimulatePnl.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Black;
            label13.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.White;
            label13.Location = new Point(333, 17);
            label13.Name = "label13";
            label13.Size = new Size(210, 29);
            label13.TabIndex = 8;
            label13.Text = "Network Devices";
            // 
            // panel12
            // 
            panel12.BackColor = Color.GreenYellow;
            panel12.Controls.Add(pictureBox18);
            panel12.Controls.Add(label8);
            panel12.Controls.Add(pictureBox10);
            panel12.Location = new Point(689, 63);
            panel12.Name = "panel12";
            panel12.Size = new Size(179, 162);
            panel12.TabIndex = 7;
            // 
            // pictureBox18
            // 
            pictureBox18.Image = Properties.Resources.accept;
            pictureBox18.Location = new Point(149, 120);
            pictureBox18.Margin = new Padding(4, 5, 4, 5);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(26, 37);
            pictureBox18.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox18.TabIndex = 2;
            pictureBox18.TabStop = false;
            pictureBox18.Visible = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.White;
            label8.ContextMenuStrip = contextMenuStrip1;
            label8.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(51, 10);
            label8.Name = "label8";
            label8.Size = new Size(76, 25);
            label8.TabIndex = 1;
            label8.Text = "Switch";
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Switche;
            pictureBox10.Location = new Point(36, 52);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(104, 108);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 0;
            pictureBox10.TabStop = false;
            // 
            // panel11
            // 
            panel11.BackColor = Color.GreenYellow;
            panel11.Controls.Add(pictureBox17);
            panel11.Controls.Add(label7);
            panel11.Controls.Add(pictureBox3);
            panel11.Location = new Point(473, 63);
            panel11.Name = "panel11";
            panel11.Size = new Size(179, 162);
            panel11.TabIndex = 7;
            // 
            // pictureBox17
            // 
            pictureBox17.Image = Properties.Resources.accept;
            pictureBox17.Location = new Point(150, 120);
            pictureBox17.Margin = new Padding(4, 5, 4, 5);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(26, 37);
            pictureBox17.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox17.TabIndex = 2;
            pictureBox17.TabStop = false;
            pictureBox17.Visible = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.White;
            label7.ContextMenuStrip = contextMenuStrip1;
            label7.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(50, 12);
            label7.Name = "label7";
            label7.Size = new Size(76, 25);
            label7.TabIndex = 1;
            label7.Text = "Server";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(43, 53);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(94, 97);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // panel10
            // 
            panel10.BackColor = Color.GreenYellow;
            panel10.Controls.Add(pictureBox16);
            panel10.Controls.Add(label14);
            panel10.Controls.Add(label6);
            panel10.Controls.Add(pictureBox2);
            panel10.Location = new Point(246, 63);
            panel10.Name = "panel10";
            panel10.Size = new Size(179, 162);
            panel10.TabIndex = 7;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = Properties.Resources.accept;
            pictureBox16.Location = new Point(147, 118);
            pictureBox16.Margin = new Padding(4, 5, 4, 5);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(26, 37);
            pictureBox16.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox16.TabIndex = 2;
            pictureBox16.TabStop = false;
            pictureBox16.Visible = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.White;
            label14.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(256, 0);
            label14.Name = "label14";
            label14.Size = new Size(109, 25);
            label14.TabIndex = 1;
            label14.Text = "Desktop 2";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.White;
            label6.ContextMenuStrip = contextMenuStrip1;
            label6.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(34, 10);
            label6.Name = "label6";
            label6.Size = new Size(109, 25);
            label6.TabIndex = 1;
            label6.Text = "Desktop 2";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.computer;
            pictureBox2.Location = new Point(36, 52);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(104, 108);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel16
            // 
            panel16.BackColor = Color.GreenYellow;
            panel16.Controls.Add(pictureBox22);
            panel16.Controls.Add(label12);
            panel16.Controls.Add(pictureBox14);
            panel16.Location = new Point(689, 253);
            panel16.Name = "panel16";
            panel16.Size = new Size(179, 162);
            panel16.TabIndex = 7;
            // 
            // pictureBox22
            // 
            pictureBox22.Image = Properties.Resources.accept;
            pictureBox22.Location = new Point(146, 118);
            pictureBox22.Margin = new Padding(4, 5, 4, 5);
            pictureBox22.Name = "pictureBox22";
            pictureBox22.Size = new Size(26, 37);
            pictureBox22.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox22.TabIndex = 2;
            pictureBox22.TabStop = false;
            pictureBox22.Visible = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.White;
            label12.ContextMenuStrip = contextMenuStrip1;
            label12.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(20, 10);
            label12.Name = "label12";
            label12.Size = new Size(137, 25);
            label12.TabIndex = 1;
            label12.Text = "Smart Phone";
            // 
            // pictureBox14
            // 
            pictureBox14.Image = Properties.Resources.smartphone;
            pictureBox14.Location = new Point(36, 47);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(104, 108);
            pictureBox14.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox14.TabIndex = 0;
            pictureBox14.TabStop = false;
            // 
            // panel15
            // 
            panel15.BackColor = Color.GreenYellow;
            panel15.Controls.Add(pictureBox21);
            panel15.Controls.Add(label11);
            panel15.Controls.Add(pictureBox13);
            panel15.Location = new Point(473, 257);
            panel15.Name = "panel15";
            panel15.Size = new Size(179, 162);
            panel15.TabIndex = 7;
            // 
            // pictureBox21
            // 
            pictureBox21.Image = Properties.Resources.accept;
            pictureBox21.Location = new Point(150, 120);
            pictureBox21.Margin = new Padding(4, 5, 4, 5);
            pictureBox21.Name = "pictureBox21";
            pictureBox21.Size = new Size(26, 37);
            pictureBox21.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox21.TabIndex = 2;
            pictureBox21.TabStop = false;
            pictureBox21.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.White;
            label11.ContextMenuStrip = contextMenuStrip1;
            label11.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(49, 10);
            label11.Name = "label11";
            label11.Size = new Size(78, 25);
            label11.TabIndex = 1;
            label11.Text = "Laptop";
            // 
            // pictureBox13
            // 
            pictureBox13.Image = Properties.Resources.laptop;
            pictureBox13.Location = new Point(36, 52);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(104, 108);
            pictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox13.TabIndex = 0;
            pictureBox13.TabStop = false;
            // 
            // panel14
            // 
            panel14.BackColor = Color.GreenYellow;
            panel14.Controls.Add(pictureBox20);
            panel14.Controls.Add(label10);
            panel14.Controls.Add(pictureBox12);
            panel14.Location = new Point(246, 253);
            panel14.Name = "panel14";
            panel14.Size = new Size(179, 162);
            panel14.TabIndex = 7;
            // 
            // pictureBox20
            // 
            pictureBox20.Image = Properties.Resources.accept;
            pictureBox20.Location = new Point(147, 120);
            pictureBox20.Margin = new Padding(4, 5, 4, 5);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new Size(26, 37);
            pictureBox20.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox20.TabIndex = 2;
            pictureBox20.TabStop = false;
            pictureBox20.Visible = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.White;
            label10.ContextMenuStrip = contextMenuStrip1;
            label10.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(43, 10);
            label10.Name = "label10";
            label10.Size = new Size(86, 25);
            label10.TabIndex = 1;
            label10.Text = "Firewall";
            // 
            // pictureBox12
            // 
            pictureBox12.Image = Properties.Resources.firewall;
            pictureBox12.Location = new Point(36, 52);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(104, 108);
            pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox12.TabIndex = 0;
            pictureBox12.TabStop = false;
            // 
            // panel13
            // 
            panel13.BackColor = Color.GreenYellow;
            panel13.Controls.Add(pictureBox19);
            panel13.Controls.Add(label9);
            panel13.Controls.Add(pictureBox11);
            panel13.Location = new Point(23, 253);
            panel13.Name = "panel13";
            panel13.Size = new Size(179, 162);
            panel13.TabIndex = 7;
            // 
            // pictureBox19
            // 
            pictureBox19.Image = Properties.Resources.accept;
            pictureBox19.Location = new Point(147, 118);
            pictureBox19.Margin = new Padding(4, 5, 4, 5);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(26, 37);
            pictureBox19.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox19.TabIndex = 2;
            pictureBox19.TabStop = false;
            pictureBox19.Visible = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.White;
            label9.ContextMenuStrip = contextMenuStrip1;
            label9.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(47, 10);
            label9.Name = "label9";
            label9.Size = new Size(75, 25);
            label9.TabIndex = 1;
            label9.Text = "Router";
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(36, 48);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(104, 108);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 0;
            pictureBox11.TabStop = false;
            // 
            // panel8
            // 
            panel8.BackColor = Color.GreenYellow;
            panel8.Controls.Add(pictureBox15);
            panel8.Controls.Add(label5);
            panel8.Controls.Add(pictureBox1);
            panel8.Location = new Point(23, 63);
            panel8.Name = "panel8";
            panel8.Size = new Size(179, 162);
            panel8.TabIndex = 7;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = Properties.Resources.accept;
            pictureBox15.Location = new Point(149, 120);
            pictureBox15.Margin = new Padding(4, 5, 4, 5);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(26, 37);
            pictureBox15.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox15.TabIndex = 2;
            pictureBox15.TabStop = false;
            pictureBox15.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.White;
            label5.ContextMenuStrip = contextMenuStrip1;
            label5.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(34, 10);
            label5.Name = "label5";
            label5.Size = new Size(109, 25);
            label5.TabIndex = 1;
            label5.Text = "Desktop 1";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.pc;
            pictureBox1.Location = new Point(36, 48);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(104, 108);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel9
            // 
            panel9.BackColor = Color.YellowGreen;
            panel9.Dock = DockStyle.Bottom;
            panel9.Location = new Point(0, 440);
            panel9.Name = "panel9";
            panel9.Size = new Size(891, 38);
            panel9.TabIndex = 6;
            // 
            // TrapButton
            // 
            TrapButton.BackColor = Color.Black;
            TrapButton.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point);
            TrapButton.ForeColor = Color.White;
            TrapButton.Location = new Point(765, 15);
            TrapButton.Name = "TrapButton";
            TrapButton.Size = new Size(105, 33);
            TrapButton.TabIndex = 9;
            TrapButton.Text = "TRAP";
            TrapButton.UseVisualStyleBackColor = false;
            TrapButton.Click += TrapButton_Click;
            // 
            // FarmMain
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1101, 517);
            Controls.Add(StatisticPnl);
            Controls.Add(SimulatePnl);
            Controls.Add(LoginPnl);
            Controls.Add(HomePnl);
            Controls.Add(UpperPnl);
            Controls.Add(LeftPnl);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FarmMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            LeftPnl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            StatisticPnl.ResumeLayout(false);
            UpperPnl.ResumeLayout(false);
            UpperPnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)FormMaximizePic).EndInit();
            ((System.ComponentModel.ISupportInitialize)FormMinimizePic).EndInit();
            ((System.ComponentModel.ISupportInitialize)FormClosePic).EndInit();
            HomePnl.ResumeLayout(false);
            HomePnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            LoginPnl.ResumeLayout(false);
            LoginFarmPnl.ResumeLayout(false);
            LoginFarmPnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            contextMenuStrip1.ResumeLayout(false);
            SimulatePnl.ResumeLayout(false);
            SimulatePnl.PerformLayout();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel LeftPnl;
        private Panel UpperPnl;
        private Button ButtonHome;
        private Panel HomePnl;
        private Panel PnlOnButtonHome;
        private Panel panel3;
        private Button button3;
        private Panel panel2;
        private Button ButtonLogin;
        private Panel panel1;
        private Button ButtonSimulate;
        private PictureBox FormMaximizePic;
        private PictureBox FormMinimizePic;
        private PictureBox FormClosePic;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox4;
        private TextBox textBox1;
        private Button button4;
        private Button button5;
        private Panel panel4;
        private Panel LoginPnl;
        private Panel panel6;
        private PictureBox pictureBox5;
        private Panel LoginFarmPnl;
        private Label label3;
        private Panel panel5;
        private PictureBox pictureBox7;
        private Button button6;
        private Panel panel7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox6;
        private TextBox TxtPassword;
        private TextBox TxtUserName;
        private PictureBox pictureBox9;
        private Label label4;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem connectToolStripMenuItem;
        private ToolStripMenuItem viewDataToolStripMenuItem;
        private Panel SimulatePnl;
        private Label label13;
        private Panel panel12;
        private Label label8;
        private PictureBox pictureBox10;
        private Panel panel11;
        private Label label7;
        private PictureBox pictureBox3;
        private Panel panel10;
        private Label label6;
        private PictureBox pictureBox2;
        private Panel panel16;
        private Label label12;
        private PictureBox pictureBox14;
        private Panel panel15;
        private Label label11;
        private PictureBox pictureBox13;
        private Panel panel14;
        private Label label10;
        private PictureBox pictureBox12;
        private Panel panel13;
        private Label label9;
        private PictureBox pictureBox11;
        private Panel panel8;
        private Label label5;
        private PictureBox pictureBox1;
        private Panel panel9;
        private PictureBox pictureBox18;
        private PictureBox pictureBox17;
        private PictureBox pictureBox16;
        private Label label14;
        private PictureBox pictureBox22;
        private PictureBox pictureBox21;
        private PictureBox pictureBox20;
        private PictureBox pictureBox19;
        private PictureBox pictureBox15;
        private ToolStripMenuItem sendMessageToolStripMenuItem;
        private ToolStripMenuItem desktop1ToolStripMenuItem;
        private ToolStripMenuItem desktop2ToolStripMenuItem;
        private ToolStripMenuItem serverToolStripMenuItem;
        private ToolStripMenuItem routerToolStripMenuItem;
        private ToolStripMenuItem laptopToolStripMenuItem;
        private ToolStripMenuItem smartPhoneToolStripMenuItem;
        private Panel StatisticPnl;
        private Panel panel18;
        private RichTextBox statsOut;
        private Button TrapButton;
    }
}